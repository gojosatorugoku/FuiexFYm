# FuiexFY Android music player

FuiexFY is an AMOLED-black Android music player with:
- Local music library scanning using Android MediaStore
- Playback in the background through AndroidX Media3 MediaSessionService
- Play/pause/previous/next controls and media notification/lock-screen integration
- Streaming from a user-supplied direct HTTP(S) audio URL (for example, a compatible MP3 or audio stream)

## Important online playback limitation
This is not a Spotify or YouTube Music client and does not search or unlock their catalogs. Use direct audio URLs you own or are authorized to play. Some websites require cookies, login, special headers, or DRM and will not work as direct links.

## Build a debug APK
Requirements: JDK 17 and Gradle 8.9, Android SDK Platform 35.
From this folder run:
`gradle assembleDebug`
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Build free from your phone
1. Create a GitHub account and a new repository named `FuiexFY`.
2. Upload the contents of this project folder (not the outer ZIP folder) to the repository.
3. Open the repository's **Actions** tab and run **Build FuiexFY APK**.
4. When the workflow finishes, open the successful run and download the `FuiexFY-debug-apk` artifact.
5. Extract the artifact ZIP on your Android phone and tap `app-debug.apk` to install. Android may ask you to allow installs from that source.

This is a debug APK signed with the debug key. It is suitable for personal testing, not Play Store publishing.
