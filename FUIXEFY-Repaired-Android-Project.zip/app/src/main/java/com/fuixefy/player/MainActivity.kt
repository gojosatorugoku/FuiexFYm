package com.fuixefy.player

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.fuixefy.player.service.PlaybackService

private data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val uri: Uri
)

class MainActivity : ComponentActivity() {
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var tracks by mutableStateOf<List<Track>>(emptyList())
    private var permissionGranted by mutableStateOf(false)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            permissionGranted = hasAudioPermission()
            if (permissionGranted) loadTracks()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionGranted = hasAudioPermission()
        if (permissionGranted) loadTracks() else requestAudioPermission()
        connectController()

        setContent {
            FuiexTheme {
                FuiexHome(
                    tracks = tracks,
                    permissionGranted = permissionGranted,
                    onRequestPermission = { requestAudioPermission() },
                    onRefresh = { loadTracks() },
                    onPlayTrack = { index -> playLocal(index) },
                    onPlayUrl = { url -> playUrl(url) },
                    controllerProvider = { controller }
                )
            }
        }
    }

    private fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestAudioPermission() {
        val permissions = mutableListOf(
            if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
            else Manifest.permission.READ_EXTERNAL_STORAGE
        )
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        permissionLauncher.launch(permissions.toTypedArray())
    }

    private fun loadTracks() {
        if (!hasAudioPermission()) return
        val result = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.IS_MUSIC
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(
            collection, projection, selection, null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                result.add(
                    Track(
                        id = id,
                        title = cursor.getString(titleCol) ?: "Unknown title",
                        artist = cursor.getString(artistCol) ?: "Unknown artist",
                        uri = ContentUris.withAppendedId(collection, id)
                    )
                )
            }
        }
        tracks = result
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
            } catch (_: Exception) {
                controller = null
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun playLocal(index: Int) {
        val c = controller ?: return
        val items = tracks.map { track ->
            MediaItem.Builder()
                .setUri(track.uri)
                .setMediaMetadata(
                    MediaMetadata.Builder().setTitle(track.title).setArtist(track.artist).build()
                )
                .build()
        }
        if (items.isNotEmpty() && index in items.indices) {
            c.setMediaItems(items, index, 0L)
            c.prepare()
            c.play()
        }
    }

    private fun playUrl(rawUrl: String) {
        val c = controller ?: return
        val cleanUrl = rawUrl.trim()
        if (cleanUrl.startsWith("https://") || cleanUrl.startsWith("http://")) {
            c.setMediaItem(MediaItem.fromUri(cleanUrl))
            c.prepare()
            c.play()
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}

@Composable
private fun FuiexTheme(content: @Composable () -> Unit) {
    val black = Color(0xFF050505)
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFFF493D),
            secondary = Color(0xFFFF725E),
            background = black,
            surface = Color(0xFF111111),
            surfaceVariant = Color(0xFF1B1B1B),
            onPrimary = Color.White,
            onBackground = Color(0xFFF5F5F5),
            onSurface = Color(0xFFF5F5F5)
        ),
        content = content
    )
}

@Composable
private fun FuiexHome(
    tracks: List<Track>,
    permissionGranted: Boolean,
    onRequestPermission: () -> Unit,
    onRefresh: () -> Unit,
    onPlayTrack: (Int) -> Unit,
    onPlayUrl: (String) -> Unit,
    controllerProvider: () -> MediaController?
) {
    var streamUrl by remember { mutableStateOf("") }
    var currentTitle by remember { mutableStateOf("Nothing playing") }
    var currentArtist by remember { mutableStateOf("Choose a song to begin") }
    var isPlaying by remember { mutableStateOf(false) }
    var controller by remember { mutableStateOf<MediaController?>(null) }

    LaunchedEffect(Unit) {
        repeat(20) {
            val found = controllerProvider()
            if (found != null) {
                controller = found
                currentTitle = found.mediaMetadata.title?.toString() ?: "Nothing playing"
                currentArtist = found.mediaMetadata.artist?.toString() ?: "FuiexFY player"
                isPlaying = found.isPlaying
                return@LaunchedEffect
            }
            kotlinx.coroutines.delay(250)
        }
    }

    DisposableEffect(controller) {
        val c = controller
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                currentTitle = mediaMetadata.title?.toString() ?: "Online stream"
                currentArtist = mediaMetadata.artist?.toString() ?: "FuiexFY"
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                currentTitle = mediaItem?.mediaMetadata?.title?.toString()
                    ?: mediaItem?.localConfiguration?.uri?.lastPathSegment ?: "Playing audio"
                currentArtist = mediaItem?.mediaMetadata?.artist?.toString() ?: "FuiexFY"
            }
        }
        c?.addListener(listener)
        onDispose { c?.removeListener(listener) }
    }

    Scaffold(
        containerColor = Color(0xFF050505),
        bottomBar = {
            NowPlayingBar(
                title = currentTitle,
                artist = currentArtist,
                playing = isPlaying,
                onPlayPause = {
                    controller?.let { if (it.isPlaying) it.pause() else it.play() }
                },
                onNext = { controller?.seekToNextMediaItem() },
                onPrevious = { controller?.seekToPreviousMediaItem() }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding)
                .background(Color(0xFF050505))
                .padding(horizontal = 20.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("FUIEX", color = Color(0xFFFF493D), fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    Text("FY", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                }
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh library", tint = Color.White)
                }
            }

            Text("YOUR SOUND. YOUR SPACE.", color = Color(0xFF8D8D8D), fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(16.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF15100F)),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Wifi, contentDescription = null, tint = Color(0xFFFF6255))
                        Spacer(Modifier.width(9.dp))
                        Text("PLAY FROM A LINK", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = streamUrl,
                        onValueChange = { streamUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Paste a direct audio URL") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFF493D),
                            unfocusedBorderColor = Color(0xFF51403E)
                        )
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { onPlayUrl(streamUrl) },
                        enabled = streamUrl.startsWith("https://") || streamUrl.startsWith("http://"),
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF493D))
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("STREAM AUDIO")
                    }
                    Text("Use a direct MP3 or compatible stream URL. Some sites block external playback.", color = Color(0xFF9B8C89), fontSize = 11.sp)
                }
            }

            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("YOUR LIBRARY", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("${tracks.size} songs found on this device", color = Color(0xFF8D8D8D), fontSize = 12.sp)
                }
                TextButton(onClick = onRefresh) { Text("SCAN", color = Color(0xFFFF6255)) }
            }
            Spacer(Modifier.height(10.dp))

            if (!permissionGranted) {
                Column(
                    Modifier.fillMaxWidth().padding(top = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.LibraryMusic, contentDescription = null, tint = Color(0xFFFF6255), modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Allow audio access to find your music", color = Color.White)
                    Button(onClick = onRequestPermission) { Text("GRANT ACCESS") }
                }
            } else if (tracks.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("No local songs found. Add audio files to your phone and scan again.", color = Color(0xFF999999))
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    itemsIndexed(tracks, key = { _, item -> item.id }) { index, track ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onPlayTrack(index) }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(44.dp).background(Color(0xFF1B1B1B), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = Color(0xFFFF6255))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(track.artist, color = Color(0xFF888888), fontSize = 12.sp, maxLines = 1)
                            }
                            Icon(Icons.Default.PlayCircle, contentDescription = "Play ${track.title}", tint = Color(0xFFFF6255))
                        }
                        HorizontalDivider(color = Color(0xFF202020))
                    }
                }
            }
        }
    }
}

@Composable
private fun NowPlayingBar(
    title: String,
    artist: String,
    playing: Boolean,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit
) {
    Surface(color = Color(0xFF151515), tonalElevation = 8.dp) {
        Column {
            HorizontalDivider(color = Color(0xFFFF493D), thickness = 2.dp)
            Row(
                Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text(artist, color = Color(0xFF929292), fontSize = 11.sp, maxLines = 1)
                }
                IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", tint = Color.White) }
                IconButton(onClick = onPlayPause) {
                    Icon(
                        if (playing) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                        contentDescription = if (playing) "Pause" else "Play",
                        tint = Color(0xFFFF493D),
                        modifier = Modifier.size(34.dp)
                    )
                }
                IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, contentDescription = "Next", tint = Color.White) }
            }
        }
    }
}
